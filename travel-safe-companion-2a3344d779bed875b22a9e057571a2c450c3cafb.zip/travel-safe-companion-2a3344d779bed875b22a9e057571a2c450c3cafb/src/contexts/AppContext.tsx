import React, { createContext, useContext, useState } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  age: number;
  interests: string;
  touristId: string;
  tripInfo?: {
    city: string;
    placesVisited: string[];
    visitTimings: string;
    currentLocation?: string;
  };
}

interface Alert {
  id: string;
  type: 'panic' | 'geofence' | 'noMovement';
  message: string;
  timestamp: Date;
  location?: { lat: number; lng: number };
}

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  safetyScore: number;
  setSafetyScore: (score: number) => void;
  alerts: Alert[];
  addAlert: (alert: Omit<Alert, 'id'>) => void;
  currentLocation: { lat: number; lng: number } | null;
  setCurrentLocation: (location: { lat: number; lng: number } | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [safetyScore, setSafetyScore] = useState(100);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);

  const addAlert = (alert: Omit<Alert, 'id'>) => {
    const newAlert: Alert = {
      ...alert,
      id: Date.now().toString(),
    };
    setAlerts(prev => [newAlert, ...prev]);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        safetyScore,
        setSafetyScore,
        alerts,
        addAlert,
        currentLocation,
        setCurrentLocation,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};