import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LanguageSelector } from '@/components/ui/language-selector';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import { Shield, MapPin } from 'lucide-react';

const Login: React.FC = () => {
  const { t } = useLanguage();
  const { setUser } = useApp();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    age: '',
    interests: '',
  });

  const generateTouristId = () => {
    return 'TS' + Date.now().toString().slice(-8);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUser = {
      id: '1',
      name: 'Tourist User',
      email: formData.email,
      age: 25,
      interests: 'Culture, Food',
      touristId: generateTouristId(),
      tripInfo: {
        city: 'Guwahati, Assam',
        placesVisited: ['Kamakhya Temple', 'Assam State Museum'],
        visitTimings: '09:00 - 18:00',
        currentLocation: 'Fancy Bazaar',
      },
    };
    
    setUser(mockUser);
    setIsLoading(false);
    navigate('/dashboard');
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser = {
      id: Date.now().toString(),
      name: formData.name,
      email: formData.email,
      age: parseInt(formData.age),
      interests: formData.interests,
      touristId: generateTouristId(),
      tripInfo: {
        city: 'Guwahati, Assam',
        placesVisited: ['Kamakhya Temple', 'Assam State Museum', 'Umananda Temple'],
        visitTimings: '09:00 - 18:00',
        currentLocation: 'Guwahati Railway Station',
      },
    };
    
    setUser(newUser);
    setIsLoading(false);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Shield className="h-8 w-8 text-secondary" />
            <h1 className="text-3xl font-bold text-primary-foreground">TravelSafe</h1>
          </div>
          <div className="flex justify-center">
            <LanguageSelector />
          </div>
        </div>

        <Card className="shadow-travel-lg border-0">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login" className="text-sm font-medium">
                {t('login')}
              </TabsTrigger>
              <TabsTrigger value="signup" className="text-sm font-medium">
                {t('signUp')}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-xl font-semibold text-primary">
                  {t('welcomeBack')}
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  Enter your credentials to access your account
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleLogin} className="space-y-4">
                  <div>
                    <Label htmlFor="email" className="text-sm font-medium">
                      {t('email')}
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      className="mt-1"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="password" className="text-sm font-medium">
                      {t('password')}
                    </Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                      className="mt-1"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary-dark text-primary-foreground font-semibold py-2.5 transition-smooth"
                    disabled={isLoading}
                  >
                    {isLoading ? t('loading') : t('login')}
                  </Button>
                </form>
              </CardContent>
            </TabsContent>

            <TabsContent value="signup">
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-xl font-semibold text-primary">
                  {t('getStarted')}
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  Create your account to start using TravelSafe
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSignUp} className="space-y-4">
                  <div>
                    <Label htmlFor="name" className="text-sm font-medium">
                      {t('name')}
                    </Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      className="mt-1"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="signup-email" className="text-sm font-medium">
                      {t('email')}
                    </Label>
                    <Input
                      id="signup-email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      className="mt-1"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="signup-password" className="text-sm font-medium">
                      {t('password')}
                    </Label>
                    <Input
                      id="signup-password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                      className="mt-1"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="age" className="text-sm font-medium">
                      {t('age')}
                    </Label>
                    <Input
                      id="age"
                      type="number"
                      value={formData.age}
                      onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                      className="mt-1"
                      min="1"
                      max="120"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="interests" className="text-sm font-medium">
                      {t('interests')}
                    </Label>
                    <Input
                      id="interests"
                      value={formData.interests}
                      onChange={(e) => setFormData(prev => ({ ...prev, interests: e.target.value }))}
                      className="mt-1"
                      placeholder="Culture, Food, Adventure..."
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-secondary hover:bg-secondary-light text-secondary-foreground font-semibold py-2.5 transition-smooth"
                    disabled={isLoading}
                  >
                    {isLoading ? t('loading') : t('createAccount')}
                  </Button>
                </form>
              </CardContent>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
};

export default Login;