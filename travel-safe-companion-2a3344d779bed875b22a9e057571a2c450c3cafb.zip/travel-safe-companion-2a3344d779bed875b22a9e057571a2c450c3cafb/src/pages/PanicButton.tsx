import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import { ArrowLeft, AlertTriangle, Phone, CheckCircle } from 'lucide-react';

const PanicButton: React.FC = () => {
  const { t } = useLanguage();
  const { currentLocation, addAlert } = useApp();
  const navigate = useNavigate();
  const [isPanicActivated, setIsPanicActivated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handlePanicPress = async () => {
    setIsLoading(true);
    
    // Get current location if not available
    let location = currentLocation;
    if (!location) {
      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0,
          });
        });
        location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
      } catch (error) {
        // Use mock location if geolocation fails
        location = { lat: 26.1445, lng: 91.7362 };
      }
    }

    // Simulate emergency service notification
    await new Promise(resolve => setTimeout(resolve, 2000));

    addAlert({
      type: 'panic',
      message: t('panicTriggered'),
      timestamp: new Date(),
      location,
    });

    setIsLoading(false);
    setIsPanicActivated(true);
  };

  const resetPanic = () => {
    setIsPanicActivated(false);
  };

  if (isPanicActivated) {
    return (
      <div className="min-h-screen bg-muted">
        {/* Header */}
        <header className="bg-background shadow-card border-b sticky top-0 z-10">
          <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/dashboard')}
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-safety-good" />
              <h1 className="text-lg font-semibold text-safety-good">{t('emergencyAlert')}</h1>
            </div>
          </div>
        </header>

        <div className="max-w-md mx-auto p-4 space-y-6">
          {/* Success Alert */}
          <Alert className="border-safety-good bg-safety-good/10">
            <CheckCircle className="h-4 w-4 text-safety-good" />
            <AlertDescription className="text-safety-good font-semibold">
              {t('helpOnWay')}
            </AlertDescription>
          </Alert>

          {/* Confirmation Card */}
          <Card className="shadow-card text-center">
            <CardContent className="pt-8 pb-8">
              <div className="w-20 h-20 bg-safety-good rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-10 w-10 text-white" />
              </div>
              <h2 className="text-xl font-bold text-foreground mb-4">
                Emergency Alert Sent
              </h2>
              <p className="text-muted-foreground mb-4">
                {t('policeNotified')}
              </p>
              {currentLocation && (
                <div className="bg-muted rounded-lg p-3 mb-6">
                  <p className="font-mono text-sm text-foreground">
                    {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}
                  </p>
                </div>
              )}
              <p className="text-sm text-safety-good font-semibold mb-6">
                {t('helpOnWay')}
              </p>
              
              <div className="space-y-3">
                <Button
                  onClick={resetPanic}
                  className="w-full bg-primary hover:bg-primary-dark text-primary-foreground font-semibold py-3 transition-smooth"
                >
                  I'm Safe Now
                </Button>
                
                <Button
                  onClick={() => navigate('/dashboard')}
                  variant="outline"
                  className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground font-semibold py-3 transition-smooth"
                >
                  Back to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Emergency Contacts */}
          <Card className="shadow-card">
            <CardContent className="pt-6">
              <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                <Phone className="h-4 w-4" />
                Emergency Contacts
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Police:</span>
                  <span className="font-mono text-destructive">100</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Fire:</span>
                  <span className="font-mono text-destructive">101</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Ambulance:</span>
                  <span className="font-mono text-destructive">102</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-background shadow-card border-b sticky top-0 z-10">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <h1 className="text-lg font-semibold text-destructive">{t('emergencyAlert')}</h1>
          </div>
        </div>
      </header>

      <div className="max-w-md mx-auto p-4 space-y-6">
        {/* Warning Alert */}
        <Alert className="border-destructive bg-destructive/10">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <AlertDescription className="text-destructive font-semibold">
            Use only in real emergencies. Police will be notified immediately.
          </AlertDescription>
        </Alert>

        {/* Panic Button */}
        <Card className="shadow-panic">
          <CardContent className="pt-8 pb-8 text-center">
            <h2 className="text-2xl font-bold text-foreground mb-6">
              Emergency Panic Button
            </h2>
            <p className="text-muted-foreground mb-8 text-sm leading-relaxed">
              Press the button below if you're in immediate danger or need emergency assistance. 
              Your location will be shared with local authorities.
            </p>
            
            <Button
              onClick={handlePanicPress}
              disabled={isLoading}
              className="w-32 h-32 rounded-full bg-destructive hover:bg-destructive/90 text-destructive-foreground text-xl font-bold shadow-panic transition-bounce animate-pulse-panic"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
              ) : (
                <div className="text-center">
                  <AlertTriangle className="h-8 w-8 mx-auto mb-2" />
                  <span>PANIC</span>
                </div>
              )}
            </Button>

            {isLoading && (
              <p className="text-sm text-muted-foreground mt-4">
                Contacting emergency services...
              </p>
            )}
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card className="shadow-card">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-foreground mb-4">What happens when you press panic?</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5">1</div>
                <p>Your exact location is captured and sent to local police</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5">2</div>
                <p>Emergency services are automatically notified</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5">3</div>
                <p>Help will be dispatched to your location immediately</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Contacts */}
        <Card className="shadow-card">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <Phone className="h-4 w-4" />
              Emergency Contacts
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Police:</span>
                <span className="font-mono text-destructive">100</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fire:</span>
                <span className="font-mono text-destructive">101</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ambulance:</span>
                <span className="font-mono text-destructive">102</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PanicButton;