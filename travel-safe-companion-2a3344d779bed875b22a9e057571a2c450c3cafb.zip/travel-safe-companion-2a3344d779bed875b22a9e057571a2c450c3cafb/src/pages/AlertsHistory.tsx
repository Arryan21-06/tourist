import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import { ArrowLeft, History, AlertTriangle, MapPin, Clock, Calendar } from 'lucide-react';
import { format } from 'date-fns';

const AlertsHistory: React.FC = () => {
  const { t } = useLanguage();
  const { alerts } = useApp();
  const navigate = useNavigate();

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'panic':
        return <AlertTriangle className="h-4 w-4 text-destructive" />;
      case 'geofence':
        return <MapPin className="h-4 w-4 text-secondary" />;
      case 'noMovement':
        return <Clock className="h-4 w-4 text-muted-foreground" />;
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getAlertBadgeVariant = (type: string) => {
    switch (type) {
      case 'panic':
        return 'destructive';
      case 'geofence':
        return 'secondary';
      case 'noMovement':
        return 'outline';
      default:
        return 'outline';
    }
  };

  const getAlertTypeLabel = (type: string) => {
    switch (type) {
      case 'panic':
        return t('panicTriggered');
      case 'geofence':
        return t('geoFenceCrossed');
      case 'noMovement':
        return t('noMovementAlert');
      default:
        return type;
    }
  };

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-background shadow-card border-b sticky top-0 z-10">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold text-primary">{t('alertHistory')}</h1>
          </div>
        </div>
      </header>

      <div className="max-w-md mx-auto p-4">
        {alerts.length === 0 ? (
          <Card className="shadow-card">
            <CardContent className="pt-8 pb-8 text-center">
              <History className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {t('noAlerts')}
              </h3>
              <p className="text-muted-foreground text-sm mb-6">
                When alerts are triggered, they will appear here for your reference.
              </p>
              <Button
                onClick={() => navigate('/dashboard')}
                className="bg-primary hover:bg-primary-dark text-primary-foreground"
              >
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {/* Stats Card */}
            <Card className="shadow-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  Alert Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-destructive">
                      {alerts.filter(a => a.type === 'panic').length}
                    </div>
                    <div className="text-xs text-muted-foreground">Panic</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-secondary">
                      {alerts.filter(a => a.type === 'geofence').length}
                    </div>
                    <div className="text-xs text-muted-foreground">Zone</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-muted-foreground">
                      {alerts.filter(a => a.type === 'noMovement').length}
                    </div>
                    <div className="text-xs text-muted-foreground">Movement</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Alerts List */}
            <div className="space-y-3">
              {alerts.map((alert) => (
                <Card key={alert.id} className="shadow-card">
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start gap-3">
                      <div className="mt-1">
                        {getAlertIcon(alert.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={getAlertBadgeVariant(alert.type) as any} className="text-xs">
                            {getAlertTypeLabel(alert.type)}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {format(alert.timestamp, 'MMM dd, HH:mm')}
                          </span>
                        </div>
                        
                        <p className="text-sm text-foreground mb-2">
                          {alert.message}
                        </p>
                        
                        {alert.location && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <MapPin className="h-3 w-3" />
                            <span className="font-mono">
                              {alert.location.lat.toFixed(6)}, {alert.location.lng.toFixed(6)}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="pt-4 space-y-3">
              <Button
                onClick={() => navigate('/panic')}
                className="w-full bg-destructive hover:bg-destructive/90 text-destructive-foreground font-semibold py-3 transition-smooth"
              >
                <AlertTriangle className="h-5 w-5 mr-2" />
                {t('panicButton')}
              </Button>

              <Button
                onClick={() => navigate('/map')}
                variant="outline"
                className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground font-semibold py-3 transition-smooth"
              >
                <MapPin className="h-5 w-5 mr-2" />
                {t('viewMap')}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AlertsHistory;