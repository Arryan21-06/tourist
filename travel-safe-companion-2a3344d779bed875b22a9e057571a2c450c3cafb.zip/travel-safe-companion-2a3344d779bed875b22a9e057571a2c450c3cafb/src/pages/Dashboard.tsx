import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LanguageSelector } from '@/components/ui/language-selector';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import { Shield, AlertTriangle, Map, History, User, LogOut } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { t } = useLanguage();
  const { user, safetyScore } = useApp();
  const navigate = useNavigate();

  const getSafetyScoreColor = (score: number) => {
    if (score >= 80) return 'text-safety-excellent';
    if (score >= 60) return 'text-safety-good';
    if (score >= 40) return 'text-safety-warning';
    return 'text-safety-danger';
  };

  const getSafetyScoreBg = (score: number) => {
    if (score >= 80) return 'bg-safety-excellent';
    if (score >= 60) return 'bg-safety-good';
    if (score >= 40) return 'bg-safety-warning';
    return 'bg-safety-danger';
  };

  if (!user) {
    navigate('/');
    return null;
  }

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-background shadow-card border-b">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold text-primary">TravelSafe</h1>
          </div>
          <div className="flex items-center gap-2">
            <LanguageSelector />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                // Handle logout
                navigate('/');
              }}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Welcome Card */}
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <User className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Welcome, {user.name}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">{t('touristId')}:</span>
                <Badge variant="outline" className="font-mono">
                  {user.touristId}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Safety Score Card */}
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              {t('safetyScore')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center">
              <div className="relative">
                <div className="w-24 h-24 rounded-full border-8 border-muted flex items-center justify-center">
                  <div
                    className={`w-20 h-20 rounded-full ${getSafetyScoreBg(safetyScore)} flex items-center justify-center`}
                  >
                    <span className="text-2xl font-bold text-white">
                      {safetyScore}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <p className="text-center text-sm text-muted-foreground mt-3">
              Current safety status
            </p>
          </CardContent>
        </Card>

        {/* Trip Info Card */}
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Map className="h-5 w-5 text-primary" />
              {t('tripInfo')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-start">
                <span className="text-muted-foreground">City:</span>
                <span className="text-right font-medium">
                  {user.tripInfo?.city || 'Guwahati, Assam'}
                </span>
              </div>
              <div className="flex justify-between items-start">
                <span className="text-muted-foreground">Places:</span>
                <div className="text-right">
                  {user.tripInfo?.placesVisited?.map((place, index) => (
                    <div key={index} className="text-xs bg-secondary/10 text-secondary px-2 py-1 rounded mb-1 last:mb-0">
                      {place}
                    </div>
                  )) || (
                    <div className="space-y-1">
                      <div className="text-xs bg-secondary/10 text-secondary px-2 py-1 rounded">Kamakhya Temple</div>
                      <div className="text-xs bg-secondary/10 text-secondary px-2 py-1 rounded">Assam State Museum</div>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex justify-between items-start">
                <span className="text-muted-foreground">Schedule:</span>
                <span className="text-right text-xs">
                  {user.tripInfo?.visitTimings || '09:00 - 18:00'}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 gap-3">
          <Button
            onClick={() => navigate('/panic')}
            className="bg-destructive hover:bg-destructive/90 text-destructive-foreground font-semibold py-6 text-lg shadow-panic transition-smooth"
          >
            <AlertTriangle className="h-6 w-6 mr-2" />
            {t('panicButton')}
          </Button>

          <Button
            onClick={() => navigate('/map')}
            variant="outline"
            className="py-6 text-lg font-semibold border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-smooth"
          >
            <Map className="h-6 w-6 mr-2" />
            {t('viewMap')}
          </Button>

          <Button
            onClick={() => navigate('/alerts')}
            variant="outline"
            className="py-6 text-lg font-semibold border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground transition-smooth"
          >
            <History className="h-6 w-6 mr-2" />
            {t('alertsHistory')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;