import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import { ArrowLeft, MapPin, Navigation, AlertTriangle } from 'lucide-react';

const MapView: React.FC = () => {
  const { t } = useLanguage();
  const { currentLocation, setCurrentLocation, addAlert } = useApp();
  const navigate = useNavigate();
  const [isInRestrictedZone, setIsInRestrictedZone] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  // Mock restricted zones (in a real app, this would come from an API)
  const restrictedZones = [
    { lat: 26.1445, lng: 91.7362, radius: 0.01 }, // Example: Guwahati restricted area
  ];

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const newLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setCurrentLocation(newLocation);
          checkRestrictedZone(newLocation);
          setLocationError(null);
        },
        (error) => {
          console.error('Error getting location:', error);
          setLocationError('Unable to get your location. Please enable location services.');
          // Set mock location for demo
          const mockLocation = { lat: 26.1445, lng: 91.7362 };
          setCurrentLocation(mockLocation);
          checkRestrictedZone(mockLocation);
        }
      );
    } else {
      setLocationError('Geolocation is not supported by this browser.');
      // Set mock location for demo
      const mockLocation = { lat: 26.1445, lng: 91.7362 };
      setCurrentLocation(mockLocation);
      checkRestrictedZone(mockLocation);
    }
  };

  const checkRestrictedZone = (location: { lat: number; lng: number }) => {
    const isRestricted = restrictedZones.some(zone => {
      const distance = Math.sqrt(
        Math.pow(location.lat - zone.lat, 2) + Math.pow(location.lng - zone.lng, 2)
      );
      return distance < zone.radius;
    });

    if (isRestricted && !isInRestrictedZone) {
      setIsInRestrictedZone(true);
      addAlert({
        type: 'geofence',
        message: t('restrictedZoneAlert'),
        timestamp: new Date(),
        location,
      });
    } else if (!isRestricted) {
      setIsInRestrictedZone(false);
    }
  };

  useEffect(() => {
    getCurrentLocation();
    
    // Watch position for real-time updates
    const watchId = navigator.geolocation?.watchPosition(
      (position) => {
        const newLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setCurrentLocation(newLocation);
        checkRestrictedZone(newLocation);
      },
      (error) => {
        console.error('Error watching location:', error);
      },
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 }
    );

    return () => {
      if (watchId) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-background shadow-card border-b sticky top-0 z-10">
        <div className="max-w-md mx-auto px-4 py-4 flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold text-primary">{t('mapView')}</h1>
          </div>
        </div>
      </header>

      <div className="max-w-md mx-auto p-4 space-y-4">
        {/* Restricted Zone Alert */}
        {isInRestrictedZone && (
          <Alert className="border-destructive bg-destructive/10">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <AlertDescription className="text-destructive font-semibold">
              {t('restrictedZoneAlert')}
            </AlertDescription>
          </Alert>
        )}

        {/* Location Error */}
        {locationError && (
          <Alert className="border-secondary bg-secondary/10">
            <AlertTriangle className="h-4 w-4 text-secondary" />
            <AlertDescription className="text-secondary">
              {locationError}
            </AlertDescription>
          </Alert>
        )}

        {/* Map Container */}
        <Card className="shadow-card overflow-hidden">
          <div className="relative bg-gradient-to-br from-primary/5 to-secondary/5 h-96 flex items-center justify-center">
            {/* Mock Map Interface */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10">
              {/* Grid lines to simulate map */}
              <div className="absolute inset-0 opacity-20">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div key={`h-${i}`} className="absolute border-t border-gray-300" style={{ top: `${i * 5}%`, width: '100%' }} />
                ))}
                {Array.from({ length: 15 }).map((_, i) => (
                  <div key={`v-${i}`} className="absolute border-l border-gray-300" style={{ left: `${i * 6.67}%`, height: '100%' }} />
                ))}
              </div>
              
              {/* Current Location Marker */}
              {currentLocation && (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="relative">
                    <div className="w-6 h-6 bg-primary rounded-full border-4 border-white shadow-lg animate-pulse"></div>
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-primary/20 rounded-full animate-ping"></div>
                  </div>
                </div>
              )}

              {/* Restricted Zone Indicator */}
              {isInRestrictedZone && (
                <div className="absolute bottom-4 right-4">
                  <div className="w-16 h-16 bg-destructive/20 border-2 border-destructive rounded-full flex items-center justify-center">
                    <AlertTriangle className="h-6 w-6 text-destructive" />
                  </div>
                </div>
              )}
            </div>

            {/* Map Overlay Info */}
            <div className="relative z-10 text-center">
              <div className="bg-background/90 backdrop-blur-sm rounded-lg p-4 shadow-card">
                <h3 className="font-semibold text-primary mb-2">{t('currentLocation')}</h3>
                {currentLocation ? (
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>Lat: {currentLocation.lat.toFixed(6)}</p>
                    <p>Lng: {currentLocation.lng.toFixed(6)}</p>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">{t('loading')}</p>
                )}
              </div>
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            onClick={getCurrentLocation}
            className="w-full bg-primary hover:bg-primary-dark text-primary-foreground font-semibold py-3 transition-smooth"
          >
            <Navigation className="h-5 w-5 mr-2" />
            Update Location
          </Button>

          <Button
            onClick={() => navigate('/panic')}
            variant="outline"
            className="w-full border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground font-semibold py-3 transition-smooth"
          >
            <AlertTriangle className="h-5 w-5 mr-2" />
            {t('panicButton')}
          </Button>
        </div>

        {/* Location Info */}
        {currentLocation && (
          <Card className="shadow-card p-4">
            <h4 className="font-semibold text-primary mb-2">Location Details</h4>
            <div className="text-sm text-muted-foreground space-y-1">
              <p>Coordinates: {currentLocation.lat.toFixed(6)}, {currentLocation.lng.toFixed(6)}</p>
              <p>Status: {isInRestrictedZone ? 
                <span className="text-destructive font-medium">In Restricted Zone</span> : 
                <span className="text-safety-good font-medium">Safe Zone</span>
              }</p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default MapView;