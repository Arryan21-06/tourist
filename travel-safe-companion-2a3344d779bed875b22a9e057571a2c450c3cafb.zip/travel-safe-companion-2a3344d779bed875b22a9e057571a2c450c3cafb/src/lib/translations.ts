export const translations = {
  en: {
    // Auth
    login: "Login",
    signUp: "Sign Up",
    email: "Email",
    password: "Password",
    name: "Full Name",
    age: "Age",
    interests: "Interests",
    createAccount: "Create Account",
    welcomeBack: "Welcome Back",
    getStarted: "Get Started",
    
    // Dashboard
    dashboard: "Dashboard",
    touristId: "Tourist ID",
    safetyScore: "Safety Score",
    tripInfo: "Trip Information",
    panicButton: "Panic Button",
    viewMap: "View Map",
    alertsHistory: "Alerts History",
    
    // Map
    mapView: "Map View",
    currentLocation: "Current Location",
    restrictedZoneAlert: "⚠️ You are entering a restricted zone!",
    
    // Panic
    emergencyAlert: "Emergency Alert",
    policeNotified: "Police notified at coordinates:",
    helpOnWay: "Help is on the way!",
    
    // Alerts
    alertHistory: "Alert History",
    noAlerts: "No alerts recorded",
    panicTriggered: "Panic button triggered",
    geoFenceCrossed: "Geo-fence crossed",
    noMovementAlert: "No movement detected",
    
    // General
    back: "Back",
    cancel: "Cancel",
    confirm: "Confirm",
    loading: "Loading...",
  },
  
  hi: {
    // Auth
    login: "लॉगिन",
    signUp: "साइन अप",
    email: "ईमेल",
    password: "पासवर्ड",
    name: "पूरा नाम",
    age: "उम्र",
    interests: "रुचियां",
    createAccount: "खाता बनाएं",
    welcomeBack: "वापस आपका स्वागत है",
    getStarted: "शुरू करें",
    
    // Dashboard
    dashboard: "डैशबोर्ड",
    touristId: "पर्यटक आईडी",
    safetyScore: "सुरक्षा स्कोर",
    tripInfo: "यात्रा की जानकारी",
    panicButton: "पैनिक बटन",
    viewMap: "मैप देखें",
    alertsHistory: "अलर्ट इतिहास",
    
    // Map
    mapView: "मैप व्यू",
    currentLocation: "वर्तमान स्थान",
    restrictedZoneAlert: "⚠️ आप प्रतिबंधित क्षेत्र में प्रवेश कर रहे हैं!",
    
    // Panic
    emergencyAlert: "आपातकालीन अलर्ट",
    policeNotified: "पुलिस को निर्देशांक पर सूचित किया गया:",
    helpOnWay: "मदद आ रही है!",
    
    // Alerts
    alertHistory: "अलर्ट इतिहास",
    noAlerts: "कोई अलर्ट रिकॉर्ड नहीं",
    panicTriggered: "पैनिक बटन दबाया गया",
    geoFenceCrossed: "भू-बाड़ पार की गई",
    noMovementAlert: "कोई गतिविधि नहीं मिली",
    
    // General
    back: "वापस",
    cancel: "रद्द करें",
    confirm: "पुष्टि करें",
    loading: "लोड हो रहा है...",
  },
  
  as: {
    // Auth
    login: "লগিন",
    signUp: "ছাইন আপ",
    email: "ইমেইল",
    password: "পাছৱৰ্ড",
    name: "সম্পূৰ্ণ নাম",
    age: "বয়স",
    interests: "আগ্ৰহ",
    createAccount: "একাউন্ট সৃষ্টি কৰক",
    welcomeBack: "আকৌ আপোনাক স্বাগতম",
    getStarted: "আৰম্ভ কৰক",
    
    // Dashboard
    dashboard: "ডেছব'ৰ্ড",
    touristId: "পৰ্যটক আইডি",
    safetyScore: "নিৰাপত্তা স্ক'ৰ",
    tripInfo: "যাত্ৰাৰ তথ্য",
    panicButton: "পেনিক বুটন",
    viewMap: "মেপ চাওক",
    alertsHistory: "সতৰ্কবাৰ্তাৰ ইতিহাস",
    
    // Map
    mapView: "মেপ ভিউ",
    currentLocation: "বৰ্তমান স্থান",
    restrictedZoneAlert: "⚠️ আপুনি নিষিদ্ধ অঞ্চলত প্ৰৱেশ কৰিছে!",
    
    // Panic
    emergencyAlert: "জৰুৰীকালীন সতৰ্কবাৰ্তা",
    policeNotified: "স্থানাংকত আৰক্ষীক জনোৱা হৈছে:",
    helpOnWay: "সহায় আহি আছে!",
    
    // Alerts
    alertHistory: "সতৰ্কবাৰ্তাৰ ইতিহাস",
    noAlerts: "কোনো সতৰ্কবাৰ্তা ৰেকৰ্ড নাই",
    panicTriggered: "পেনিক বুটন টিপা হৈছে",
    geoFenceCrossed: "ভৌগোলিক বাৰ্ডাৰ পাৰ হৈছে",
    noMovementAlert: "কোনো চলাচল ধৰা পৰা নাই",
    
    // General
    back: "উভতি",
    cancel: "বাতিল কৰক",
    confirm: "নিশ্চিত কৰক",
    loading: "ল'ড হৈ আছে...",
  }
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.en;